<?php
//192.168.105.191
session_start();
session_destroy();

?>